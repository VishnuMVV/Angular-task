export class MovieDetails {
     movieId: number;
     movieTitle: string;
     movieRating: number;
     movieDesc: string;
     releaseYear: number;
}
